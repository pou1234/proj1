package com.niit;

import java.util.ArrayList;

public class MyCart {

	public static void main(String[] args) {
		
		
		ArrayList<PhoneStore> cart=new ArrayList<>();
		PhoneStore p1=new PhoneStore("P1001","MP3 Player",2,3000);
		PhoneStore p2=new PhoneStore("P1002","Phone",1,9000);
		PhoneStore p3=new PhoneStore("P1003","Shirt",3,5000);
		cart.add(p1);
		cart.add(p2);
		cart.add(p3);
		for(PhoneStore p:cart)
		{
System.out.println(p.getName()+ p.getPrice());			
		}
	}
}
