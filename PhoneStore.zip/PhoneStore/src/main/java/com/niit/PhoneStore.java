package com.niit;

public class PhoneStore {
private String id;
private String name;
private int noof;
private int price;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getNoof() {
	return noof;
}
public void setNoof(int noof) {
	this.noof = noof;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public PhoneStore(String id, String name, int noof, int price) {
	super();
	this.id = id;
	this.name = name;
	this.noof = noof;
	this.price = price;
}

}
