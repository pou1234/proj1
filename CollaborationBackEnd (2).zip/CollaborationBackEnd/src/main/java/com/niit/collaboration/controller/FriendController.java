package com.niit.collaboration.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.collaboration.dao.FriendDAO;
import com.niit.collaboration.model.Friend;

@RestController
public class FriendController {
	
	private static final Logger log= LoggerFactory.getLogger(FriendController.class);
	
	@Autowired
	FriendDAO friendDAO;
	
    @Autowired
    Friend friend;
    
    @RequestMapping(value="/myFriends",method= RequestMethod.GET)
    public ResponseEntity<List<Friend>> getMyFriends(HttpSession session){
    	log.debug("->->->->calling method getMyFriends");
    	String loggedInUserID= (String) session.getAttribute("loggedInUserID");
    	
    	log.debug("getting friends of :" +loggedInUserID);
    	List<Friend> myFriends= friendDAO.getMyFriends(loggedInUserID);
    	
    	if(myFriends.isEmpty())
    	{
    		log.debug("Friends does not exist for the user :" + loggedInUserID);
    		friend.setErrorCode("404");
    		friend.setErrorMessage("You does not have any friends");
    		myFriends.add(friend);
    	}
    	log.debug("Send the friend list");
    	return new ResponseEntity<List<Friend>>(myFriends,HttpStatus.OK);
    	
    	 }
    	
    @RequestMapping(value="/addFriend/{friendID}",method= RequestMethod.GET)
    public ResponseEntity<Friend> sendFriendRequest(@PathVariable("friendID") String friendID,HttpSession session){
    	log.debug("->->->->caliing method sendFriendRequest");
    	String loggedInUserID= (String) session.getAttribute("loggedInUserID");
    	  friend.setUserID(loggedInUserID);
    	  friend.setFriendID(friendID);
    	  friend.setStatus("N");
    	  friend.setIsOnline('N');
    	  
    	  if (friendDAO.get(loggedInUserID,friendID) !=null){
            friend.setErrorCode("404");
            friend.setErrorMessage("You already sent the friend request");
     }
    	  else{
          friendDAO.save(friend);
          friend.setErrorCode("200");
          friend.setErrorMessage("Friend request successfull.." + friendID);
    	  }
          return new ResponseEntity<Friend>(friend,HttpStatus.OK);
          
    		  
    	  }
    	  
    @RequestMapping(value="/unfriend/{friendID}",method = RequestMethod.GET)
    public ResponseEntity<Friend> unfriend(@PathVariable("friendID") String friendID,HttpSession session){
      log.debug("->->->calling method unfriend");
      updateRequest(friendID,"U",session);
      return new ResponseEntity<Friend>(friend,HttpStatus.OK);
    }

    @RequestMapping(value="/rejectFriend/{friendID}",method = RequestMethod.GET)
    public ResponseEntity<Friend> rejectFriendFriendRequest(@PathVariable("friendID") String friendID,HttpSession session){
    	log.debug("->->->calling method rejectFriendFriendRequest");
    	updateRequest(friendID,"R",session);
    	return new ResponseEntity<Friend>(friend,HttpStatus.OK);
    	
    }
	private void updateRequest(String friendID, String string, HttpSession session) {
		String loggedInUserID= (String) session.getAttribute("loggedInUserID");
		friend.setUserID(loggedInUserID);
  	    friend.setFriendID(friendID);
  	    friend.setStatus(friendID);
  	    friendDAO.update(friend);
  	  
		}
    	
    @RequestMapping(value="/getMyFriendRequests/",method = RequestMethod.GET)
    public ResponseEntity<List<Friend>> getMyFriendRequests(@PathVariable("friendID") String friendID,HttpSession session){
    	log.debug("->->->calling method getMyFriendRequests");
    	String loggedInUserID= (String) session.getAttribute("loggedInUserID");
    	List<Friend> myFriendRequests= friendDAO.getNewFriendRequests(loggedInUserID);
    	return new ResponseEntity<List<Friend>>(myFriendRequests,HttpStatus.OK);
    }
    
    @RequestMapping(value="/acceptFriend/{friendID}",method = RequestMethod.GET)
    public ResponseEntity<List<Friend>> acceptFriendFriendRequest(@PathVariable("friendID") String friendID,HttpSession session){
    	log.debug("->->->calling method acceptFriendFriendRequest");
    	updateRequest(friendID,"A",session);
    	return new ResponseEntity<List<Friend>>(HttpStatus.OK);
    }
  
    	
}
    
    	
    	
    

