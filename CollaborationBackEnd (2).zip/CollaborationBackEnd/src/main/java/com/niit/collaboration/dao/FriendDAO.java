package com.niit.collaboration.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.collaboration.model.Friend;

@Repository("friendDAO")
public interface FriendDAO {

	
	
	public Friend get(String userID,String friendID);
	
    public boolean save(Friend friendDetailsDetails);
	
	public boolean update(Friend friendDetailsDetails);
	
	public boolean delete(String userID,String friendID);
	
	
	
	public void setOnline(String friendID);
	
	public void setOffline(String friendID);

	public List<Friend>AllFriends();

	public List<Friend> getMyFriends(String loggedInUserID);

	public  boolean isFriend(int userID, int id);

	public List<Friend> getNewFriendRequests(String loggedInUserID);
     

 
	

	
	}
     
	


	

 
		

	


