package com.niit.collaboration.daoimpl;

import java.util.List;


import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.collaboration.dao.FriendDAO;
import com.niit.collaboration.model.Friend;
import com.niit.collaboration.model.Users;

@Repository
public class FriendDAOImpl implements FriendDAO {

	private static final Logger Log =LoggerFactory.getLogger(UserDAOImpl.class);
	
	@Autowired(required=true)
	private SessionFactory sessionFactory;
	
	
	public FriendDAOImpl(SessionFactory sessionFactory){
		try {
			this.sessionFactory = sessionFactory;
		} catch (Exception e){
		 Log.error("Unable to connect to db");
			e.printStackTrace();
		}
	}

    @Transactional
	public List<Friend> list() {
		Log.debug("->->Starting of the method list");
        @SuppressWarnings("unchecked")
        List<Friend> list = (List<Friend>) sessionFactory.getCurrentSession().createCriteria(Friend.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

    @Transactional
	public Friend get(String userID, String friendID) {
		
	        String hql="from Friend where id='" + userID + "' and " + " status = '" + friendID+ "'";
			
	        Query query = sessionFactory.getCurrentSession().createQuery(hql);
	        Log.debug("hql :"+ hql);
	        
	        return (Friend)query.uniqueResult();

	}

    @Transactional
	public boolean save(Friend friendDetailsDetails) {
		try {			
			//friendDetailsDetails.setRole("ROLE_USER");
			//friendDetailsDetails.setEnabled(true);
			sessionFactory.getCurrentSession().save(friendDetailsDetails);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

    @Transactional
	public boolean update(Friend friendDetailsDetails) {
		try {			
			sessionFactory.getCurrentSession().update(friendDetailsDetails);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
			}

    @Transactional
	public boolean delete(String userID,String friendID) {
		Friend friend=new Friend();
		friend.setFriendID(friendID);
		friend.setUserID(userID);
		sessionFactory.openSession().delete(friend);
		 return false;
    }	
	


	//public Friend authenticate(String id, String password) {
		// TODO Auto-generated method stub
		//return null;
	
    @Transactional
  public List<Friend> getMyFriends(String userID)
  {
    String hql = "from Friend where userID="+"'"+userID+"' and status ='"+"A'";
    Query query = sessionFactory.getCurrentSession().createQuery(hql);
    
     List<Friend> list = (List<Friend>)query.list();
     
      return list;
      
  }
    
    @Transactional
    public List<Friend> getNewFriendsRequests(String userID)
    {
        String hql = "from Friend where userID="+"'"+userID+"' and status ='"+"A'";
        Query query = sessionFactory.getCurrentSession().createQuery(hql);
        
         List<Friend> list = (List<Friend>)query.list();
         
          return list;
    }
          
    @Transactional
	public void setOnline(String friendID) {
		Log.debug("Starting of the method setOnline");
	    String hql="UPDATE Friend SET isOnline= 'Y' where id='" + friendID + "'";
	     Log.debug("hql:" + hql);
	     Query query=sessionFactory.getCurrentSession().createQuery(hql);
	       query.executeUpdate();
	     Log.debug("Ending of the method setOnline");
	     
		
	}

    @Transactional
	public void setOffline(String friendID) {
		 Log.debug("Starting of the method setOffline");
	 	    String hql="UPDATE User SET isOnline= 'Y' where id='" + friendID + "'";
	 	     Log.debug("hql:" + hql);
	 	     Query query=sessionFactory.getCurrentSession().createQuery(hql);
	 	       query.executeUpdate();
	 	     Log.debug("Ending of the method setOffline");
			
		
	}

    @Transactional
	public List<Friend> getAllFriends() {
		Log.debug("->->Starting of the method list");
        @SuppressWarnings("unchecked")
        List<Friend> getAllFriends = (List<Friend>) sessionFactory.getCurrentSession().createCriteria(Friend.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
       return getAllFriends();
	}
	

    @Transactional
	public List<Friend> AllFriends() {
		Log.debug("->->Starting of the method list");
        @SuppressWarnings("unchecked")
        List<Friend> AllFriends = (List<Friend>) sessionFactory.getCurrentSession().createCriteria(Users.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
       return AllFriends;
	}

	@Override
	public boolean isFriend(int userID, int id) {
		Log.debug("->->Starting of the method list");
        @SuppressWarnings("unchecked")
        List<Friend> isFriend = (List<Friend>) sessionFactory.getCurrentSession().createCriteria(Users.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
       return isFriend != null;
		
	}

	@Override
	public List<Friend>  getNewFriendRequests(String loggedInUserID) {
		Log.debug("->->Starting of the method list");
        @SuppressWarnings("unchecked")
        List<Friend> getNewFriendRequests = (List<Friend>) sessionFactory.getCurrentSession().createCriteria(Users.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
       return getNewFriendRequests;
		
		
	}

	
	}

