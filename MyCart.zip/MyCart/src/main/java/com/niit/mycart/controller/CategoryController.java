package com.niit.mycart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.niit.mycart.dao.CategoryDAO;
import com.niit.mycart.model.Category;

@Controller
public class CategoryController {

	private static Logger log= LoggerFactory.getLogger(CategoryController.class);
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private Category category;
	
	@RequestMapping(value = "/categories",method= RequestMethod.GET)
	public String listCategories(Model model){
	log.debug("Starting of the method listCategories");
		model.addAttribute("category",category);
		model.addAttribute("categoryList",this.categoryDAO.list());
		log.debug("End of the method listCategories");
		return "category";
		
	}
	@RequestMapping(value = "/category/add",method = RequestMethod.POST)
     public String addCategory(@ModelAttribute("category") Category category,Model model) {
	log.debug("Starting of the method addCategory");
	categoryDAO.save(category);
log.debug("Ending of  the method addCategory");
	return "category";
	}


	@RequestMapping(value = "/category/remove/{id}")
	public String deletecategory(@ModelAttribute("category") Category category){
	  log.debug("Starting of the method deleteCategory");
	    categoryDAO.delete(category);
	   log.debug("End of the method deleteCategory");
	
	return "category" ;
	}
	
	@RequestMapping("category/edit/{id}")
	public String editcategory(@ModelAttribute("category") Category category){
		log.debug("Starting of the method editCategory");
		categoryDAO.update(category);
		log.debug("End of the method editCategory");
		return "category";
		
		
	}
	
		
	
	}
	
	
	
	

