package com.niit.mycart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.mycart.dao.SupplierDAO;
import com.niit.mycart.model.Supplier;

@Controller
public class SupplierController {

	private static Logger log= LoggerFactory.getLogger(SupplierController.class);
	
	@Autowired
	private SupplierDAO supplierDAO;
	
	@Autowired
	private SupplierDAO supplier;
	
	@RequestMapping(value = "/suppliers",method= RequestMethod.GET)
	public String listSuppliers(Model model){
		log.debug("Starting of the method listSuppliers");
		model.addAttribute("supplier",supplier);
		model.addAttribute("supplierList",this.supplierDAO.list());
		log.debug("End of the method listSuppliers");
		return "supplier";
		
	}
	@RequestMapping(value = "/supplier/add",method = RequestMethod.POST)
     public String addSupplier(@ModelAttribute("supplier") Supplier supplier,Model model) {
	log.debug("Starting of the method addSupplier");
	supplierDAO.save(supplier);
	log.debug("Ending of  the method addSupplier");
	return "supplier";
	}


	@RequestMapping(value = "/supplier/remove/{id}")
	public String deletesupplier(@ModelAttribute("supplier") Supplier supplier){
	    log.debug("Starting of the method deleteSupplier");
	    supplierDAO.delete(supplier);
	    log.debug("End of the method deleteSupplier");
	
	return "supplier" ;
	}
	
	@RequestMapping("supplier/edit/{id}")
	public String editsupplier(@ModelAttribute("supplier") Supplier supplier){
		log.debug("Starting of the method editSupplier");
		supplierDAO.update(supplier);
		log.debug("End of the method editSupplier");
		return "supplier";
		
		
	}
	
	
	
	}
	
	
