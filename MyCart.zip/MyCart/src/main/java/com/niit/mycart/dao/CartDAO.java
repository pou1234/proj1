package com.niit.mycart.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.mycart.model.Cart;

@Repository
public interface CartDAO {

	public boolean saveOrUpdate(Cart cart);
	
	public boolean delete(Cart cart);
	
	public Cart getCartByUserId(String userId);

	public List<Cart> list();
	
	//public List<OrderedItems> listOrderedItems(String userId);
	
}
