package com.niit.mycart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.mycart.dao.CategoryDAO;
import com.niit.mycart.model.Category;

public class CategoryTestMain {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		//Here i'm going to perform basic database operations using hibernate provided functions....
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		//Category category = (Category) context.getBean("category");
		Category category = new Category();
		category.setId("CTG020");
		category.setName("CTG_name_9");
		category.setDescription("This is category001 description...");
		
				
		
		if(categoryDAO.save(category) == true){
			System.out.println("Category created successfully...");
		}
		else{
			System.out.println("Not able to create category...");
		}
		
		
		System.out.println(categoryDAO.list());		
		Category category1 = categoryDAO.get("CTG010");
		category1.setName("Furniture");
	    System.out.println(categoryDAO.update(category1));
	
	    Category category3 = new Category();
	    category3.setId("CTG013");
	    System.out.println(categoryDAO.delete(category3));
	
	    
	
	
	}
	
	


}
