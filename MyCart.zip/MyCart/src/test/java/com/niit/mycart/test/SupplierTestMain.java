package com.niit.mycart.test;

import static org.junit.Assert.*;

import org.junit.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

	import com.niit.mycart.dao.SupplierDAO;
import com.niit.mycart.model.Category;
import com.niit.mycart.model.Supplier;

	public class SupplierTestMain {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			@SuppressWarnings("resource")
			AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
			context.scan("com.niit");
			context.refresh();
			
			//Here i'm going to perform basic database operations using hibernate provided functions....
			
			SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
			//Supplier supplier = (Supplier) context.getBean("supplier");
			Supplier supplier= new Supplier();
			supplier.setId("SUP021");
			supplier.setName("Reliance Trendz");
			supplier.setAddress("Mumbai");
			
			if(supplierDAO.save(supplier) == true){
				System.out.println("Supplier created successfully...");
			}
			else{
				System.out.println("Not able to create supplier...");
			}

			Supplier supplier1= new Supplier();
			supplier1.setId("SUP01");
			System.out.println(supplierDAO.list());
			
			
			Supplier supplier2 = new Supplier();
		    supplier2.setId("SUP003");
		    System.out.println(supplierDAO.delete(supplier2));
		    
		    Supplier supplier3 = new Supplier();
		    supplier3.setId("SUP013");
		    System.out.println(supplierDAO.save(supplier3));
		
		    
		
		
		}



	}


