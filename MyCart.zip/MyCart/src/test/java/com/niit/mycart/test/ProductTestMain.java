package com.niit.mycart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.mycart.dao.ProductDAO;
import com.niit.mycart.model.Product;
import com.niit.mycart.model.Supplier;

public class ProductTestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		//Product product = (Product) context.getBean("product");
		Product product=new Product();
		product.setId("PRO002");
		product.setName("PRO_name_001");
		product.setDescription("This is product001 description...");
		product.setPrice(5000);
				
		if(productDAO.save(product) == true){
			System.out.println("Product created successfully...");
		}
		else{
			System.out.println("Not able to create product...");
		}
	
		 Product product1= new Product();
		product1.setId("PRO01");
		System.out.println(productDAO.list());
		
	     
	
	
	
	}

}

	
	
	
	


