package com.niit.mycart.test;
 
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.mycart.dao.UserDetailsDAO;
import com.niit.mycart.model.Category;
import com.niit.mycart.model.Supplier;
import com.niit.mycart.model.UserDetails;

public class UserDetailsTestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		
		UserDetailsDAO userDetailsDAO = (UserDetailsDAO) context.getBean("userDetailsDAO");
		//UserDetails userDetails = (UserDetails) context.getBean("userDetails");
		UserDetails userDetails = new UserDetails();
		userDetails.setId("USER010");
		userDetails.setName("USER_name_002");
		userDetails.setPassword("pwd003");
		userDetails.setEmail("user2@niit.com");
		userDetails.setPhone("0987654321");
		userDetails.setAddress("Delhi");
				
				
		if(userDetailsDAO.save(userDetails) == true){
			System.out.println("UserDetails created successfully...");
		}
		else{
			System.out.println("Not able to create userDetails...");
		}
	

		
		System.out.println(userDetailsDAO.list());
	
		UserDetails userDetails2  = new UserDetails();
	    userDetails2.setPassword("pwd002");
	    System.out.println(userDetailsDAO.delete(userDetails2));
	
	
	
	}
        
        
         


	}


